package com.example.pinkmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

final class PinkSlider extends SliderWidget {
    PinkSlider(int x, int y, int w, int h) {
        super(x, y, w, h, Text.empty(), (Config.range - 1) / 5.0);
        updateMessage();
    }

    private int val() {
        return 1 + (int) Math.round(value * 5);
    }

    @Override
    protected void updateMessage() {
        setMessage(Text.literal("Reichweite: " + val() + " Blöcke"));
    }

    @Override
    protected void applyValue() {
        Config.range = val();
        Config.save();
    }

    @Override
    public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Draw.rounded(ctx, getX(), getY(), getWidth(), getHeight(), 7, isHovered() ? Draw.BTN_HOVER : Draw.BTN);
        int fill = Math.max(14, (int) (getWidth() * value));
        Draw.rounded(ctx, getX(), getY(), fill, getHeight(), 7, Draw.ACCENT);
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        Text m = getMessage();
        ctx.drawText(tr, m, getX() + (getWidth() - tr.getWidth(m)) / 2,
                getY() + (getHeight() - 8) / 2, Draw.TEXT, false);
    }
}
