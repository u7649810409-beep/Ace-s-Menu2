package com.example.pinkmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class PinkMenuClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Config.load();
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("pinkmenu", "main"));
        KeyBinding open = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.pinkmenu.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        KeyBinding toggle = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.pinkmenu.autoaim", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (open.wasPressed()) mc.setScreen(new MenuScreen());
            while (toggle.wasPressed()) { Config.autoaim = !Config.autoaim; Config.save(); }
            AutoAim.tick(mc);
        });
    }
}
