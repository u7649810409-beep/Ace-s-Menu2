package com.example.pinkmenu;

import net.minecraft.client.gui.DrawContext;

/** Zeichenhelfer: abgerundete Rechtecke mit vertikalem Farbverlauf. Farben sind ARGB. */
final class Draw {
    static final int BG_TOP = 0xF0301048;
    static final int BG_BOTTOM = 0xF0701850;
    static final int BTN = 0xFF4A1F6B;
    static final int BTN_HOVER = 0xFF6A2A8F;
    static final int ACCENT = 0xFFE0409A;
    static final int TEXT = 0xFFFFFFFF;
    static final int TEXT_DIM = 0xFFD8B8E8;

    static int lerp(int a, int b, float t) {
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int ca = (a >> s) & 0xFF, cb = (b >> s) & 0xFF;
            r |= (Math.round(ca + (cb - ca) * t) & 0xFF) << s;
        }
        return r;
    }

    static void rounded(DrawContext ctx, int x, int y, int w, int h, int r, int top, int bottom) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < h; i++) {
            int inset = 0;
            int d = Math.min(i, h - 1 - i);
            if (d < r) {
                double dy = r - d - 0.5;
                inset = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            }
            int c = lerp(top, bottom, h <= 1 ? 0 : i / (float) (h - 1));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, c);
        }
    }

    static void rounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        rounded(ctx, x, y, w, h, r, color, color);
    }
}
