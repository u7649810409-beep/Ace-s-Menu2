package com.example.pinkmenu;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

final class Config {
    static boolean autoaim = false;
    static int range = 3; // 1..6 Blöcke

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pinkmenu.properties");
    }

    static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (InputStream in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            autoaim = Boolean.parseBoolean(p.getProperty("autoaim", "false"));
            range = Math.max(1, Math.min(6, Integer.parseInt(p.getProperty("range", "3"))));
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    static void save() {
        Properties p = new Properties();
        p.setProperty("autoaim", String.valueOf(autoaim));
        p.setProperty("range", String.valueOf(range));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "Pink Menu");
        } catch (IOException ignored) {
        }
    }
}
