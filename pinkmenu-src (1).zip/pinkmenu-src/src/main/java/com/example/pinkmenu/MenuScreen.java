package com.example.pinkmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

final class MenuScreen extends Screen {
    private static final int WIN_W = 440, WIN_H = 290, RADIUS = 12, PAD = 18;
    private static final String[] TABS = {"PvP", "Effekte", "Skins"};
    private static int tab = 0;

    MenuScreen() {
        super(Text.literal("Pink Menu"));
    }

    private int left() { return (width - WIN_W) / 2; }
    private int top() { return (height - WIN_H) / 2; }

    @Override
    protected void init() {
        int l = left(), t = top();
        int tabW = (WIN_W - PAD * 2 - 16) / 3;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            PinkButton b = new PinkButton(l + PAD + i * (tabW + 8), t + 44, tabW, 24,
                    Text.literal(TABS[i]), btn -> { tab = idx; clearAndInit(); });
            b.selected = (i == tab);
            addDrawableChild(b);
        }

        int cx = l + PAD, cw = WIN_W - PAD * 2, y = t + 88;
        if (tab == 0) {
            addDrawableChild(new PinkButton(cx, y, cw, 30,
                    Text.literal("Autoaim: " + (Config.autoaim ? "AN" : "AUS")),
                    btn -> { Config.autoaim = !Config.autoaim; Config.save(); clearAndInit(); }));
            addDrawableChild(new PinkSlider(cx, y + 40, cw, 26));
        }

        addDrawableChild(new PinkButton(cx, t + WIN_H - PAD - 28, cw, 28,
                Text.literal("Schließen"), btn -> close()));
    }

    /** Hintergrund: Der Blur kommt von super (Video-Einstellung "Menü-Hintergrundunschärfe"), darüber das Panel. */
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        Draw.rounded(ctx, left() - 2, top() - 2, WIN_W + 4, WIN_H + 4, RADIUS + 2, 0x60FFFFFF);
        Draw.rounded(ctx, left(), top(), WIN_W, WIN_H, RADIUS, Draw.BG_TOP, Draw.BG_BOTTOM);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawText(textRenderer, Text.literal("Pink Menu"), left() + PAD, top() + 16, Draw.TEXT, true);
        if (tab != 0) {
            ctx.drawText(textRenderer, Text.literal("Hier ist noch nichts drin."),
                    left() + PAD, top() + 96, Draw.TEXT_DIM, false);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
