package com.example.pinkmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

final class PinkButton extends ButtonWidget {
    boolean selected;

    PinkButton(int x, int y, int w, int h, Text msg, PressAction action) {
        super(x, y, w, h, msg, action, DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int c = selected ? Draw.ACCENT : (isHovered() ? Draw.BTN_HOVER : Draw.BTN);
        Draw.rounded(ctx, getX(), getY(), getWidth(), getHeight(), 7, c);
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        Text m = getMessage();
        ctx.drawText(tr, m, getX() + (getWidth() - tr.getWidth(m)) / 2,
                getY() + (getHeight() - 8) / 2, Draw.TEXT, false);
    }
}
