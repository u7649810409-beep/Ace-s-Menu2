package com.example.pinkmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Aim-Assist: zielt weich auf den nächsten feindlichen Mob in Reichweite. Zielt NICHT auf Spieler. */
final class AutoAim {
    private static final float MAX_STEP = 14f; // Grad pro Tick, damit es nicht ruckartig ist

    static void tick(MinecraftClient mc) {
        if (!Config.autoaim) return;
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.currentScreen != null) return;

        Vec3d eyes = p.getEyePos();
        double range = Config.range;
        HostileEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (HostileEntity e : w.getEntitiesByClass(HostileEntity.class,
                p.getBoundingBox().expand(range + 1), x -> x.isAlive())) {
            double d = distanceToBox(eyes, e.getBoundingBox());
            if (d <= range && d < bestD) {
                best = e;
                bestD = d;
            }
        }
        if (best == null) return;

        Vec3d t = best.getBoundingBox().getCenter();
        double dx = t.x - eyes.x, dy = t.y - eyes.y, dz = t.z - eyes.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float targetPitch = (float) -(MathHelper.atan2(dy, horiz) * 180.0 / Math.PI);

        float yawDiff = MathHelper.wrapDegrees(targetYaw - p.getYaw());
        float pitchDiff = targetPitch - p.getPitch();
        p.setYaw(p.getYaw() + MathHelper.clamp(yawDiff, -MAX_STEP, MAX_STEP));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchDiff, -MAX_STEP, MAX_STEP), -90f, 90f));
    }

    static double distanceToBox(Vec3d v, Box b) {
        double dx = Math.max(Math.max(b.minX - v.x, 0), v.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - v.y, 0), v.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - v.z, 0), v.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
