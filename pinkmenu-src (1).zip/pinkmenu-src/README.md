# Pink Menu

Fabric-Mod für Minecraft 1.21.11: Ingame-Menü (Right Shift) mit abgerundeten Ecken, Blur-Hintergrund und Autoaim (nur feindliche Mobs).

## Bauen
GitHub Actions baut bei jedem Push automatisch. Die Jar findest du unter Actions → letzter Lauf → Artifacts.
Lokal: `gradle build` (oder `./gradlew build`, falls du einen Wrapper erzeugt hast: `gradle wrapper`).
